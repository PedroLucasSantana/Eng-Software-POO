class Veiculo:
    def __init__(self,marca,modelo,ano,):
        self.marca = marca
        self.modelo = modelo
        self.ano = ano
        self.ligado = False
        self.velocidade = 0

    def __str__(self):
        return f"Dados do Veiculo: Marca: {self.marca} | Modelo: {self.modelo} | Ano: {self.ano}"
    
    def ligar(self):
        pass 
    
    def desligar(self):
        pass 
    
    def acelerar(self):
        pass

class Moto(Veiculo):
    def __init__(self, marca, modelo, ano):
        super().__init__(marca, modelo, ano)
        self.velocidade = 0

    def __str__(self):
        return f"Dados do Moto: Marca: {self.marca} | Modelo: {self.modelo} | Ano: {self.ano}"

    def ligar(self):
        self.ligado = True
        return f"Moto ligada."
    
    def desligar(self):
        if self.velocidade == 0 and self.ligado == True:
            self.ligado == False
            return f"Moto desligada."
        else:
            return f"Moto não pode desligar em movimento"

    def acelerar(self):
        if self.ligado == True:
            self.velocidade += 10
            return f"Moto em movimento - Velocidade: {self.velocidade}"
        else:
            return f"Moto não pode acelerar"
        
    def freiar(self):
        if self.velocidade > 0:
            self.velocidade -= 10
            return f"Moto Freiando - Velocidade: {self.velocidade}"
        else:
            return f"Moto já está parado"
        
class Carro(Veiculo):
    def __init__(self, marca, modelo, ano, quantportas):
        super().__init__(marca, modelo, ano)
        self.quantportas = quantportas
        self.marcha = 0
        self.portaaberta = True
        self.dentrodocarro = True

    def __str__(self):
        return f"{super().__str__()} | Quant Portas: {self.quantportas}"

    def ligar(self):
        if self.portaaberta == True and self.dentrodocarro == True:
            self.ligado = True
            return f"Carro ligado."
    
    def desligar(self):
        if self.dentrodocarro == True and self.ligado == True and self.velocidade == 0:
            self.ligado = False
            return f"Carro desligado."
        else:
            return f"Carro não pode desligar em movimento."
        
    def acelerar(self):
        if self.ligado == True:
            self.velocidade += 10
            return f"Carro em movimento - Velocidade: {self.velocidade}"
        else:
            return f"Carro não pode acelerar"
        
    def freiar(self):
        if self.velocidade > 0:
            self.velocidade -= 10
            return f"Carro Freiando - Velocidade: {self.velocidade}"
        else:
            return f"Carro já está parado"
        
    def mudarmarcha(self):
        if self.ligado == True and self.dentrodocarro:
            if self.velocidade == 0:
                self.marcha = 0
            elif 0 < self.velocidade <= 20:
                self.marcha = 1
            elif 20 < self.velocidade <= 40:
                self.marcha = 2
            elif 40 < self.velocidade <= 60:
                self.marcha = 3
            elif 60 < self.velocidade <= 80:
                self.marcha = 4
            elif self.velocidade > 80:
                self.marcha = 5

# TERMOS
m1 = Moto("Yamaha", "Fz15", 2025)
c1 = Carro("Fiat","Cronos", 2024, 4)

# AÇÕES
print("--------------------------Moto----------------------------")
print(m1.__str__())
print(m1.ligar())
print(m1.acelerar())
print(m1.acelerar())
print(m1.freiar())
print(m1.freiar())
print(m1.desligar())
print("----------------------------------------------------------")
print("----------------------------------Carro--------------------------------------")
print(c1.__str__())
print(c1.ligar())
print(c1.acelerar())
print(c1.acelerar())
print(c1.freiar())
print(c1.freiar())
print(c1.desligar())
print("-----------------------------------------------------------------------------")
