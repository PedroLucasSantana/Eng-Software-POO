class Pessoa:

    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade

    def __str__(self):
        return f"Nome: {self.nome} | Idade: {self.idade}"
    
    def apresentar(self):
        return f"Dados da Pessoa: Nome: {self.nome} | Idade: {self.idade}"
    
class Turma:

    def __init__(self, codigo, periodo):
        self.codigo = codigo
        self.periodo = periodo

    def __str__(self):
        return f"Código: {self.codigo} | Período: {self.periodo}"

    
class Professor(Pessoa):

    def __init__(self, nome, idade, disciplina, turma):
        super().__init__(nome, idade)
        self.disciplina = disciplina
        self.turma = turma

    def __str__(self):
        return f"Dados do Professor: {super().__str__()} | Disciplina: {self.disciplina} | {self.turma}"
    
class Aluno(Pessoa):

    def __init__(self, nome, idade, matricula,turma):
        super().__init__(nome, idade)
        self.matricula = matricula
        self.turma = turma

    def __str__(self):
        return f"Dados do Aluno: {super().__str__()} | Matrícula: {self.matricula} | {self.turma}"
    
# TERMOS
t1 = Turma("AIR", "B")
prof1 = Professor("Claudio", 45, "Matemática", t1)
a1 = Aluno("Marya", 19, "202422456", t1)
p1 = Pessoa("Pedro", 20)


# AÇÕES
print(p1.apresentar())
print(prof1)
print(a1)