class Pessoa:
    def __init__(self, nome, idade, cpf=None):
        self.nome = nome
        self.idade = idade
        self.__cpf = cpf

    def __str__(self):
        return f"Nome: {self.nome}\nIdade:{self.idade}\nCPF:{self.__cpf}"
    
    def cpfset(self, Cpf):
        if len(Cpf) == 11:
            self.__cpf = Cpf
        else:
            raise ValueError ("Algo deu erro")
        
class Estudante(Pessoa):
    def __init__(self,nome,idade,matricula,curso,cpf=None):
        super().__init__(nome, idade, cpf)
        self.matricula = matricula
        self.curso = curso
    def __str__(self):
        return f"{super().__str__()}\nMatricula:{self.matricula}\nCursando:{self.curso}"
    
p1 = Estudante("Pedro", 30, "2025001", "Engenharia de Software")
p1.cpfset("12345678901")
print(p1)