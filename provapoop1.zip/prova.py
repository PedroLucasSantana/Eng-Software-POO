class Livro:

    def __init__(self, titulo, autor, ano):
        self.titulo = titulo
        self.autor = autor
        self.ano = ano

    def resumo(self):
        return f"{self.titulo} | {self.autor} | {self.ano}"
    
    def __str__(self):
        return f"Livro = Titulo: {self.titulo} | Autor: {self.autor} | Ano: {self.ano}"
    
class Usuario:

    def __init__(self, nome, matricula):
        self.nome = nome
        self.matricula = matricula
        self.livros = []

    def pegarlivro(self, livro):
        self.livros.append(livro)
        return f"{self.nome} pegou o livro {livro.titulo}"
    
    def listarlivros(self):
        if not self.livros:
            return f"{self.nome} não pegou nenhum livro"
        else:
            texto = f"Livros de {self.nome} = "
            for livro in self.livros:
                texto += f"{livro.titulo} | "
            return texto
    
    def __str__(self):
        return f"Usuario = Nome: {self.nome} | Matricula: {self.matricula}"
    
class Biblioteca:

    def __init__(self, nome, endereco):
        self.nome = nome
        self.endereco = endereco
        self.livrosemprestados = []
        
    def adicionarlivro(self, livro):
        self.livrosemprestados.append(livro)
        return f"Livro = {livro.titulo} adicionado ao livros emprestados"
    
    def emprestar(self,usuario,livro):
        if livro not in self.livrosemprestados:
            return f"Livro não encontrado"
        else:
            usuario.pegarlivro(livro)
            self.livrosemprestados.append((usuario, livro))
            self.livrosemprestados.remove(livro)
            return f"{usuario.nome} pegou o livro {livro.titulo} emprestado"
        
    def listaremprestimo(self):
        if not self.livrosemprestados:
            return "Não há livros emprestados"
        else:
            texto = "Emprestimos Atuais:\n"
            for usuario, livro in self.livrosemprestados:
                texto += f"{usuario.nome} pegou {livro.titulo}\n"
            return texto
 
# TERMOS
l1 = Livro("Pequeno Principe", "Pedro", 2023)
l2 = Livro("Transform", "Claudio", 2003)
l3 = Livro("3 Porquinhos", "Santos", 1993)
u1 = Usuario("Luiz", 202422321)
u2 = Usuario("Gustavo", 202133241)
b1 = Biblioteca("Central dos livros", "Rua Isaltina Porto")

# AÇÕES
print(l1.__str__())
print(u1.__str__())
print(u1.pegarlivro(l1))
print(u1.pegarlivro(l2))
print(u1.listarlivros())
print(b1.adicionarlivro(l3))
print(b1.adicionarlivro(l1))
print(b1.emprestar(u2,l3))
print(b1.emprestar(u2,l1))
print(b1.listaremprestimo())